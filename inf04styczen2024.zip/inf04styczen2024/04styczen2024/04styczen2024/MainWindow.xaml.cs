﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace inf04styczen2024
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void obrazki(object sender, RoutedEventArgs e){ // nie działa
            string t1 = numer.Text;

            if (t1.Length == 3)
            {
                Uri resourceUri1 = new Uri("obrazy/" + t1 + "_m.jpg", UriKind.Relative);
                i_m.Source = new BitmapImage(resourceUri1);
                Uri resourceUri2 = new Uri("obrazy/" + t1 + "_f.jpg", UriKind.Relative);
                i_f.Source = new BitmapImage(resourceUri2);
            }
            


        }
        private void funkcjia(object sender, RoutedEventArgs e) {
            string t1 = numer.Text;
            string t2 = imie.Text;
            string t3 = nazwisko.Text;

            string wybranaOpcja = "";
            if (rb1.IsChecked == true) {
                wybranaOpcja = "niebieski";
            }
            else if (rb2.IsChecked == true) {
                wybranaOpcja = "zielony";
            }
            else if (rb3.IsChecked == true) {
                wybranaOpcja = "piwne";
            }
            if (t2 != "" && t3 != "" && wybranaOpcja != "")
            MessageBox.Show(t1+" "+t2+" kolor oczu "+ wybranaOpcja);
            else MessageBox.Show("„Wprowadź dane”");
        }
    }
}